auto();
var str;
var str1;
//启动通知栏监控
events.observeNotification();
events.on("notification", function(n){

    if(n.getTitle()!=null){
         if(n.getPackageName()=="com.eg.android.AlipayGphone"){
       
         str =n.getTitle();
        //通过正则判断提取
         str1=str.match(/你已成功收款(.*)元/); 
        if(str1==null){
          //toast("匹配失败！");
         }else{
         //获取成功
         log(str1);
         log(str1[1]);
         //调用api
         var response=payApi(str1[1]);
         /*response为对象类型 {
      "status":1,  //0为
      "message":"网络异常"
      };
         */
         toast("状态码:"+response.status);
         toast(response.message);
          }
    }else{
    log(n.getTitle());
    }
 }
log(n.getTitle());
    //判断是否为支付宝
    
});

//支付异步回调api
function payApi(money){
    //本地数据获取
    var storage=storages.create("pay");
    var data=storage.get("paySite");
    //接口地址
    var url=data.url;
    //传输内容
    var data1={
    "ID": data.ID,
    "key": data.key,
    "money":money
      };
    //发起请求
    var res = http.get(url+"?ID="+data1.ID+"&key="+data1.key+"&money="+money);
    log(res.statusCode);
    //res响应判断
    if(res.statusCode == 404){
      
      return {
      "status":1,
      "message":"网络异常"
      };
    }else if(res.statusCode >= 200 && res.statusCode < 300){
        //回调成功
       var resp=res.body.json();
       log(resp);
       return resp;
    }else{
       return {
     "status":3,
     "message":"未知异常"
             };
  }
}
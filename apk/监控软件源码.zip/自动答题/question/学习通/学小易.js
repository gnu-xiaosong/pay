var window = floaty.window(
    <frame gravity="center">
        <text id="text" textSize="16sp" textColor="#f44336"/>
    </frame>
);

window.exitOnClose();

window.text.click(()=>{
    window.setAdjustEnabled(!window.isAdjustEnabled());
});


toast("正在初始化……耐心等待10秒开始");

setInterval(function(){
     
    var ty=dynamicText();
    //对控件的操作需要在UI线程中执行
    ui.run(function(){
        window.text.setText(ty);
    });
    toast("等待7秒自动开始，请立即切换回答题页面并马上作答");
    }, 7000);

function dynamicText(){


/*****************控件获取↓↓↓↓↓↓↓↓************************************/

    /*多重控件定位:
      ①depth值--------->采用暴力遍历判断，找一个确定的depth值，如果返回null再进行for i++遍历获取
      ②基于坐标的定位:bounds  先确定常用的bounds值依次获取判断
    */
   
    /* 
   // ①depth值
   var depth=4;   //尽量填写准确值，以减少程序运行压力
   var text;
   //确定值判断控件是否存在
   var  is=className("android.view.View").indexInParent(2).drawingOrder(0).depth(depth).exists();
   
   if(!text){
   //控件不存在
     for(var i=0;i<=99;i++){
     is=className("android.view.View").indexInParent(2).drawingOrder(0).depth(i).exists();
     log(is);
     if(is){
     //匹配成功,获取text并退出循环
        text=className("android.view.View").indexInParent(2).drawingOrder(0).depth(i).findOne().getText();
        break;
        }
     if(i==99){
       //单行获取
       is=className("android.view.View").indexInParent(2).drawingOrder(0).bounds(41,377,1039,451).exists();
       if(is){
       text=className("android.view.View").indexInParent(2).drawingOrder(0).bounds(41,377,1039,451).findOne().getText();
       break;
       }
       //当遍历完还找到控件也采用bounds获取(两行)
       is=className("android.view.View").indexInParent(2).drawingOrder(0).bounds(41,377,1039,523).exists();
       if(is){
       //匹配控件成功
       text=className("android.view.View").indexInParent(2).drawingOrder(0).bounds(41,377,1039,523).findOne().getText();
       break;
       }
       //三行获取
       is=className("android.view.View").indexInParent(2).drawingOrder(0).bounds(41,377,1039,592).exists();
       if(is){
       text=className("android.view.View").indexInParent(2).drawingOrder(0).bounds(41,377,1039,592).findOne().getText();
       break;
       }
       
       }
     }
   }else{
   //控件存在
   text=className("android.view.View").indexInParent(2).drawingOrder(0).depth(depth).findOne().getText();
   }
     
 /*****************控件获取↑↑↑↑↑↑↑↑↑↑↑************************************/
    /*
    //获取题目
    var  text=getControl(5,"android.widget.TextView",1,0);
    //获取图(二进制文件)
    var  img=getControl(5,"android.widget.Image",2,0);
    
    */
    //获取题目
    var  text=getControl(5,"android.widget.TextView",2,0);
    //获取图(二进制文件)
    var  img=getControl(5,"android.widget.Image",2,0);
    
    
     log(text);
     if(text.text==null){
         //页面检测
     return "未能识别智慧树答题页面，请切换至答题页面";
     }else{
     //对学小易应用进行操作
     // launch("com.xuexiaoyi.xxy");
     log("这里");
     launchApp("学小易");
     sleep(2000);
     
          //智能化处理
     while(true){
     if(className("android.view.ViewGroup").desc("搜题").exists()){
     //基于控件点击
     className("android.view.ViewGroup").desc("搜题").findOne().click();
        //坐标点击
       click(405,2229);
       break;
       }
      }
     
     

     //防止程序中断再次点击
     click(405,2229);
     
    //className("android.widget.ImageView").depth(14).indexInParent(0).drawingOrder(1).bounds(369,2170,441,2242).findOne().click();
     sleep(1000);
     //获取题目内容自动查找
     setText(text.text);
     //点击搜索
     click(525,1363);
      //className("android.widget.TextView").bounds(452,1328,628,1387).click();
      //className("android.widget.TextView").text("立即搜索").bounds(452,1328,628,1387).findOne().click();
      toast("请手动切换至知到，选择答案,");
      
      //防止网络异常原因防止失败这里添加判断
      //获取答案
     var data=getControl(6,"android.widget.TextView",1,2);
     var k=0;
     while(!data.is){
     toast("获取控件对象失败，请检查网络");
      k++;
     //循环获取
     data=getControl(6,"android.widget.TextView",1,2);
     //判断控件存在性
     if(data.is){
     data=getControl(6,"android.widget.TextView",1,2);
     break;
     }
     //k值判断
     if(k==50){
     toast("正在尝试重新获取……");
     }
     if(k==1000){
     toast("正在尝试重新获取……");
     }
     }
     
    
    
    
     log(data.text)
    // var data=className("android.widget.TextView").indexInParent(1).drawingOrder(2).depth(6).findOne().getText();
     //返回智慧树并并显示答案
     //launchApp("知到")
     //提交到服务器
     
     var q=text.text+img;
     res=http.get("http://api.xskj.store/index.php/app?q="+q+"&a="+data.text);
     log(res.statusCode);
     return data.text;
         }
}

//控件暴力获取方法
function getControl(depth1,className1,indexInParent1,drawingOrder1){
/*****************控件获取↓↓↓↓↓↓↓↓************************************/
   
    
   /*@param depth 默认depth值
     *@param className 控件类名
      多重控件定位:
      ①depth值--------->采用暴力遍历判断，找一个确定的depth值，如果返回null再进行for i++遍历获取
      ②基于坐标的定位:bounds  先确定常用的bounds值依次获取判断
    */
    
   // ①depth值
   log(className1);
   var text;
   //确定值判断控件是否存在
   var  is=className(className1).indexInParent(indexInParent1).drawingOrder(drawingOrder1).depth(depth1).exists();
   if(!is){
   //控件不存在
     for(var i=0;i<=99;i++){
     //排除学习通部分文字影响
     if(i==4){
     i++;
     }
     is=className(className1).indexInParent(indexInParent1).drawingOrder(drawingOrder1).depth(i).exists();
     log(is);
     if(is){
     //匹配成功,获取text并退出循环
        text=className(className1).indexInParent(indexInParent1).drawingOrder(drawingOrder1).depth(i).findOne().getText();
        break;
        }
        /***************bounds匹配控件↓↓↓↓↓↓↓**********/
        //修改对应bounds值即可
     if(i==99){
       //单行获取
       is=className(className1).indexInParent(indexInParent1).drawingOrder(drawingOrder1).bounds(41,377,1039,451).exists();
       if(is){
       text=className(className1).indexInParent(indexInParent1).drawingOrder(drawingOrder1).bounds(41,377,1039,451).findOne().getText();
       break;
       }
       //当遍历完还找到控件也采用bounds获取(两行)
       is=className(className1).indexInParent(indexInParent1).drawingOrder(drawingOrder1).bounds(41,377,1039,523).exists();
       if(is){
       //匹配控件成功
       text=className(className1).indexInParent(indexInParent1).drawingOrder(drawingOrder1).bounds(41,377,1039,523).findOne().getText();
       break;
       }
       //三行获取
       is=className(className1).indexInParent(indexInParent1).drawingOrder(drawingOrder1).bounds(41,377,1039,592).exists();
       if(is){
       text=className(className1).indexInParent(indexInParent1).drawingOrder(drawingOrder1).bounds(41,377,1039,592).findOne().getText();
       break;
       }
       }
     /***************bounds匹配控件↑↑↑↑↑↑**********/
     
     }
   }else{
   //控件存在
   text=className(className1).indexInParent(indexInParent1).drawingOrder(drawingOrder1).depth(depth1).findOne().getText();
   }
   //判断控件存在函数
   var is=className(className1).indexInParent(indexInParent1).drawingOrder(drawingOrder1).depth(depth1).exists();
   return {
   "text":text,
   "is":is
   };
}
var   text=className("android.view.View").indexInParent(2).drawingOrder(0).depth(5).findOne().getText();
alert(text);
app.startActivity({
        data:"mqqwpa://im/chat?chat_type=wpa&uin=1829134124"
    });
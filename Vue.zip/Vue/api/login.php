<?php
include("./database.php");
$username=$_GET["username"];  //字符串
$password=$_GET["password"];

//商户验证
$conn = new mysqli($servername, $user, $paw,$dbname);
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}
$sql="SELECT * FROM pay_user where username=".$username;
$result=mysqli_query($conn, $sql);
$row=mysqli_fetch_array($result);
//var_dump($row);
if(empty($row)){
$data1=array(
"code"=>201,
"message"=>"该账户不存在！"
);
echo json_encode($data1);
exit();
}

if((string)$row["password"]!=$password){
$data2=array(
"code"=>203,
"message"=>"密码错误！"
);
echo json_encode($data2);
exit();
}
//验证成功，返回数据
$data=array(
"code"=>200,
"message"=>"验证通过！",
"id"=>(int)$row["id"]   //返回商户id
);

echo json_encode($data);
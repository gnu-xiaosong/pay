<?php
include("./database.php");
//首页api接口调用文件
$id=1;//$_GET["id"];
//首页信息接口
$conn = new mysqli($servername, $user, $paw,$dbname);
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}
$sql="SELECT * FROM pay_order where user_id=".$id;
$result=mysqli_query($conn, $sql);

//var_dump($row);

if(empty($row)){
$data1=array(
"code"=>500,             //状态码
"message"=>"没有查询单该账户订单信息"
);
echo json_encode($data1);
exit();
}
$i=0;
$order=array();
while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
//计算商品总金额
$tatol+=$row["money"];   //获取交易总金额
$order[$i]=$row;
$i++;
}
echo $tatol;
//订单信息返回
$data=array(
"code"=>200,             //状态码
"counts"=>count($row),   //订单总数
"order"=>$row,           //返回详细订单信息
"message"=>"获取订单信息成功！"
);
echo json_encode($data);



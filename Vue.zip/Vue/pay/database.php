<?php
//数据库配置文件

$servername = "localhost";
$username = "root";
$password = "";
$dbname="xskj";
<?php
//数据库配置文件

$servername = "localhost";
$username = "sql_103_152_170_";
$password = "fs123456";
$dbname="sql_103_152_170_";
<?php
//网页端付款状态循环请求状态接口
header('content-type:application:json;charset=utf8');  
include("./database.php");
//用于客服端请求数据处理
$user_id=$_GET["user_id"];  //商户id
$order_no=$_GET["order_no"];  //订单编号

//数据库订单查询支付订单状态
//连接数据库
$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}
$sql="select * from pay_order where user_id=".$user_id." and order_no=".$order_no;
$result=mysqli_query($conn, $sql);
$row=mysqli_fetch_assoc($result);
//var_dump($row);
if(empty($row)){
$data0=array(
'code'=>400,
'message'=>"该账单不存在！",
);
echo json_encode($data0);
exit();
}
//判断支付状态
if($row["status"]==0){
//未支付完成
$data1=array(
'code'=>300,
'message'=>"未支付完成，可能已掉单！",
);
echo json_encode($data1);
exit();
}
//支付状态完成

$data=array(
'code'=>200,
'message'=>"支付成功！正在跳转中……",
);
echo json_encode($data);
exit();


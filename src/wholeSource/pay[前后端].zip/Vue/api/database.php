<?php
//数据库配置文件

$servername = "localhost";
$user = "root";
$paw = "";
$dbname="xskj";
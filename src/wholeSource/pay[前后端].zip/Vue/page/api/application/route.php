<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
//规则:('替换名','所在模块名/类名/方法名');
use  think\Route;

Route::rule('api1','index/index/api1');
Route::rule('order','order/Order/order');
Route::rule('setAbutmentInformation','order/Order/setAbutmentInformation');
Route::rule('setPersonInformation','order/Order/setPersonInformation');
Route::rule('get','order/Order/get');